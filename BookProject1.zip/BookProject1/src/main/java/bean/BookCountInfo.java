package bean;

import java.util.Arrays;

public class BookCountInfo {
    private int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "BookCountInfo{" +
                "count=" + count +
                '}';
    }
}

