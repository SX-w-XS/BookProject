package utils;

import com.mysql.cj.jdbc.MysqlDataSource;
import org.apache.commons.dbutils.QueryRunner;

/**
 * MySQL工具类：
 * 用于连接MySQL
 */
public class MyDBUtils {
    private static MysqlDataSource dataSource;

    static {
        dataSource = new MysqlDataSource();
        dataSource.setUser("root");
        dataSource.setPassword("root");
        dataSource.setUrl("jdbc:mysql://localhost:3306/db_book?serverTimezone=UTC");
    }

    public static QueryRunner getQueryRunner(){
        return new QueryRunner(dataSource);
    }
}
